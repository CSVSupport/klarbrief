// /api/mail/inbound.js
// Postmark Inbound Webhook — receives forwarded emails and creates projects automatically
//
// Setup:
// 1. In Postmark: Create an inbound server
// 2. Set webhook URL to: https://klarbrief24.de/api/mail/inbound
// 3. Configure inbound domain: mail.klarbrief24.de (MX records point to inbound.postmarkapp.com)
// 4. Each user's address: {mail_forward_token}@mail.klarbrief24.de
//    → Postmark forwards to this webhook, payload includes "To" field
//
// ENV required:
//   ANTHROPIC_API_KEY
//   VITE_SUPABASE_URL (or SUPABASE_URL)
//   SUPABASE_SERVICE_ROLE_KEY

import { createClient } from '@supabase/supabase-js';

const ANTHROPIC_MODEL = 'claude-sonnet-4-20250514';

export const config = {
  api: { bodyParser: { sizeLimit: '25mb' } },
};

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();

  const supabaseUrl = process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  const anthropicKey = process.env.ANTHROPIC_API_KEY;

  if (!supabaseUrl || !serviceKey || !anthropicKey) {
    console.error('Missing env vars');
    return res.status(500).json({ error: 'Server not configured' });
  }

  const supabase = createClient(supabaseUrl, serviceKey);

  try {
    const payload = req.body;

    // Postmark sends: { To, From, Subject, TextBody, HtmlBody, Attachments: [{ Name, Content (base64), ContentType }] }
    const toAddress = (payload.To || payload.ToFull?.[0]?.Email || '').toLowerCase();
    const fromAddress = (payload.From || payload.FromFull?.Email || '').toLowerCase();
    const subject = payload.Subject || 'Eingehende E-Mail';
    const textBody = payload.TextBody || '';
    const htmlBody = payload.HtmlBody || '';
    const attachments = payload.Attachments || [];

    console.log(`Inbound mail: to=${toAddress} from=${fromAddress} subject="${subject}" attachments=${attachments.length}`);

    // Extract token from "token@mail.klarbrief24.de"
    const tokenMatch = toAddress.match(/^([a-z0-9]+)@mail\./);
    if (!tokenMatch) {
      console.error('Invalid recipient format:', toAddress);
      return res.status(200).json({ ok: true, message: 'ignored — invalid recipient' });
    }
    const token = tokenMatch[1];

    // Look up user by token
    const { data: profile, error: profileErr } = await supabase
      .from('profiles')
      .select('id, email, plan')
      .eq('mail_forward_token', token)
      .maybeSingle();

    if (profileErr || !profile) {
      console.error('No user for token:', token, profileErr);
      return res.status(200).json({ ok: true, message: 'ignored — unknown recipient' });
    }

    const userId = profile.id;

    // Find first PDF or image attachment
    const docAttachment = attachments.find(a => {
      const t = (a.ContentType || '').toLowerCase();
      return t === 'application/pdf' || t.startsWith('image/');
    });

    let analysisInput;
    let fileData = null;

    if (docAttachment) {
      const isPdf = docAttachment.ContentType === 'application/pdf';
      fileData = {
        base64: docAttachment.Content,
        mediaType: docAttachment.ContentType,
        isImage: !isPdf,
        isPdf,
        fileName: docAttachment.Name || 'Anhang',
      };
      analysisInput = { type: 'file', fileData };
    } else {
      // Fallback: analyze email body as text
      const bodyText = textBody || htmlBody.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
      analysisInput = { type: 'text', text: `Betreff: ${subject}\nVon: ${fromAddress}\n\n${bodyText}` };
    }

    // Call Claude for analysis
    const systemPrompt = `Du bist KlarBrief24, ein KI-Assistent der Behördenbriefe analysiert.
Antworte IMMER mit validem JSON im folgenden Schema (keine Markdown-Code-Blöcke):
{
  "klartext": "2-3 Sätze einfache Erklärung",
  "ampel": "rot"|"gelb"|"gruen",
  "todos": ["Aufgabe 1", "Aufgabe 2"],
  "frist": "YYYY-MM-DD" oder null,
  "kategorie": "Steuern"|"Miete"|"Soziales"|"Bußgeld"|"Versicherung"|"Arbeit"|"Gesundheit"|"Rechnung"|"Vertrag"|"Sonstiges",
  "behoerde": "Name der Behörde/Firma",
  "betreff": "Kurzer Betreff",
  "projektname": "Vorgeschlagener Projektname",
  "aktenzeichen": "Aktenzeichen" oder null,
  "referenzen": ["Aktenzeichen", "Steuernr", ...],
  "dokumenttyp": "Bescheid"|"Rechnung"|"Mahnung"|"Vertrag"|"Brief"|"Sonstiges"
}`;

    let messages;
    if (analysisInput.type === 'file') {
      messages = [{ role: 'user', content: [
        analysisInput.fileData.isPdf
          ? { type: 'document', source: { type: 'base64', media_type: 'application/pdf', data: analysisInput.fileData.base64 } }
          : { type: 'image', source: { type: 'base64', media_type: analysisInput.fileData.mediaType, data: analysisInput.fileData.base64 } },
        { type: 'text', text: `Analysiere dieses Dokument. Betreff der E-Mail: "${subject}". Absender: ${fromAddress}.` }
      ]}];
    } else {
      messages = [{ role: 'user', content: `Analysiere diese E-Mail:\n\n${analysisInput.text}` }];
    }

    let result;
    try {
      const resp = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'x-api-key': anthropicKey,
          'anthropic-version': '2023-06-01',
          'content-type': 'application/json',
        },
        body: JSON.stringify({ model: ANTHROPIC_MODEL, max_tokens: 1500, system: systemPrompt, messages }),
      });
      const data = await resp.json();
      const raw = data.content?.[0]?.text || '{}';
      result = JSON.parse(raw.replace(/```json|```/g, '').trim());
    } catch (e) {
      console.error('Anthropic error:', e);
      result = {
        klartext: `E-Mail von ${fromAddress} erhalten — bitte manuell prüfen.`,
        ampel: 'gelb',
        todos: ['E-Mail manuell prüfen'],
        frist: null,
        kategorie: 'Sonstiges',
        behoerde: fromAddress,
        betreff: subject,
        projektname: subject.substring(0, 60),
        aktenzeichen: null,
        referenzen: [],
        dokumenttyp: 'Brief',
      };
    }

    // Build letter entry (without base64 for DB)
    const letter = {
      id: Date.now(),
      date: new Date().toLocaleDateString('de-DE'),
      direction: 'eingehend',
      type: result.dokumenttyp || 'Brief',
      summary: result.klartext,
      betreff: result.betreff || subject,
      analyzed: true,
      source: 'email',
      fromAddress,
      emailSubject: subject,
      document: fileData ? { mediaType: fileData.mediaType, isImage: fileData.isImage, isPdf: fileData.isPdf, fileName: fileData.fileName } : null,
      originalText: analysisInput.type === 'text' ? analysisInput.text : null,
    };

    // Try smart matching: find existing project with same aktenzeichen or close topic
    const { data: existingProjects } = await supabase
      .from('projects')
      .select('*')
      .eq('user_id', userId)
      .eq('archived', false);

    let targetProject = null;
    if (result.aktenzeichen && existingProjects) {
      targetProject = existingProjects.find(p => p.aktenzeichen && p.aktenzeichen === result.aktenzeichen);
    }

    if (targetProject) {
      // Append to existing project
      const updatedLetters = [...(targetProject.letters || []), letter];
      const updatedRefs = [...(targetProject.referenzen || []), ...(result.referenzen || [])].filter((v, i, a) => a.indexOf(v) === i);
      await supabase.from('projects').update({
        letters: updatedLetters,
        ampel: result.ampel || targetProject.ampel,
        frist: result.frist || targetProject.frist,
        referenzen: updatedRefs,
      }).eq('id', targetProject.id);
      console.log(`Appended to existing project ${targetProject.id}`);
    } else {
      // Create new project
      const newProject = {
        user_id: userId,
        name: result.projektname || subject.substring(0, 60),
        category: result.kategorie || 'Sonstiges',
        status: 'offen',
        ampel: result.ampel || 'gelb',
        behoerde: result.behoerde || fromAddress,
        frist: result.frist || null,
        aktenzeichen: result.aktenzeichen || '',
        referenzen: result.referenzen || [],
        dokumenttyp: result.dokumenttyp || null,
        letters: [letter],
        archived: false,
      };
      const { data: created, error: createErr } = await supabase.from('projects').insert([newProject]).select().single();
      if (createErr) console.error('Failed to create project:', createErr);
      else console.log(`Created new project ${created.id} for user ${userId}`);
    }

    // Increment usage
    const currentMonth = `${new Date().getFullYear()}-${String(new Date().getMonth() + 1).padStart(2, '0')}`;
    const { data: existingUsage } = await supabase.from('usage_tracking').select('count').eq('user_id', userId).eq('month', currentMonth).maybeSingle();
    if (existingUsage) {
      await supabase.from('usage_tracking').update({ count: existingUsage.count + 1 }).eq('user_id', userId).eq('month', currentMonth);
    } else {
      await supabase.from('usage_tracking').insert([{ user_id: userId, month: currentMonth, count: 1 }]);
    }

    return res.status(200).json({ ok: true });
  } catch (err) {
    console.error('Inbound error:', err);
    return res.status(200).json({ ok: false, error: err.message }); // still 200 so Postmark doesn't retry endlessly
  }
}
